const axios = require('axios');
const cron = require('node-cron');

// Configuration
const ASANA_TOKEN = '2/1207755089881347/1215155318943143:94d6a518fc0c7c44890225eb49eee6ec';
const SLACK_BOT_TOKEN = 'xoxb-484389626759-11201812236679-2BZ1Ojqq5oV8ZAXX7oeUvBzx';
const SLACK_USER_ID = 'U07A8885UEB';

const asanaApi = axios.create({
  baseURL: 'https://app.asana.com/api/1.0',
  headers: {
    'Authorization': `Bearer ${ASANA_TOKEN}`
  }
});

const slackApi = axios.create({
  baseURL: 'https://slack.com/api',
  headers: {
    'Authorization': `Bearer ${SLACK_BOT_TOKEN}`
  }
});

// Get current user from Asana
async function getCurrentUser() {
  try {
    const response = await asanaApi.get('/users/me');
    return response.data.data;
  } catch (error) {
    console.error('Error fetching current user:', error.message);
    throw error;
  }
}

// Get all workspaces
async function getWorkspaces() {
  try {
    const response = await asanaApi.get('/workspaces');
    return response.data.data;
  } catch (error) {
    console.error('Error fetching workspaces:', error.message);
    throw error;
  }
}

// Get projects owned by user in a workspace
async function getOwnedProjects(workspaceId, userId) {
  try {
    const response = await asanaApi.get(`/workspaces/${workspaceId}/projects`, {
      params: {
        owner: userId,
        archived: false,
        opt_fields: 'gid,name,owner'
      }
    });
    return response.data.data;
  } catch (error) {
    console.error(`Error fetching owned projects for workspace ${workspaceId}:`, error.message);
    return [];
  }
}

// Get tasks assigned to user
async function getUserTasks(workspaceId, userId) {
  try {
    const response = await asanaApi.get('/tasks', {
      params: {
        assignee: userId,
        workspace: workspaceId,
        completed_since: 'now',
        opt_fields: 'gid,name,due_on,projects,assignee,completed'
      }
    });
    return response.data.data;
  } catch (error) {
    console.error(`Error fetching user tasks for workspace ${workspaceId}:`, error.message);
    return [];
  }
}

// Get tasks in projects owned by user
async function getTasksInOwnedProjects(projectIds) {
  try {
    const allTasks = [];
    for (const projectId of projectIds) {
      const response = await asanaApi.get(`/projects/${projectId}/tasks`, {
        params: {
          completed_since: 'now',
          opt_fields: 'gid,name,due_on,assignee,completed,projects'
        }
      });
      allTasks.push(...response.data.data);
    }
    return allTasks;
  } catch (error) {
    console.error('Error fetching tasks in owned projects:', error.message);
    return [];
  }
}

// Get project details
async function getProjectDetails(projectId) {
  try {
    const response = await asanaApi.get(`/projects/${projectId}`, {
      params: {
        opt_fields: 'gid,name'
      }
    });
    return response.data.data;
  } catch (error) {
    console.error(`Error fetching project ${projectId}:`, error.message);
    return null;
  }
}

// Filter tasks due today or overdue
function filterDueTodayOrOverdue(tasks) {
  const today = new Date().toISOString().split('T')[0];
  return tasks.filter(task => {
    if (!task.due_on) return false;
    return task.due_on <= today && !task.completed;
  });
}

// Group tasks by project
async function groupTasksByProject(tasks) {
  const grouped = {};
  
  for (const task of tasks) {
    if (task.projects && task.projects.length > 0) {
      const projectId = task.projects[0].gid;
      const projectName = task.projects[0].name;
      
      if (!grouped[projectName]) {
        grouped[projectName] = [];
      }
      grouped[projectName].push(task);
    }
  }
  
  return grouped;
}

// Format message for Slack
async function formatSlackMessage(groupedTasks) {
  if (Object.keys(groupedTasks).length === 0) {
    return "✅ No overdue or due today tasks!";
  }

  let message = "📋 *Asana Task Summary – Due Today or Overdue*\n\n";
  
  for (const [projectName, tasks] of Object.entries(groupedTasks)) {
    message += `*${projectName}*\n`;
    for (const task of tasks) {
      const dueDate = task.due_on ? new Date(task.due_on).toLocaleDateString('en-AU') : 'No due date';
      message += `• [ ] ${task.name} (Due: ${dueDate})\n`;
    }
    message += "\n";
  }
  
  return message;
}

// Send message to Slack
async function sendSlackMessage(message) {
  try {
    const response = await slackApi.post('/chat.postMessage', {
      channel: SLACK_USER_ID,
      text: message,
      mrkdwn: true
    });
    
    if (response.data.ok) {
      console.log('Message sent to Slack successfully');
    } else {
      console.error('Slack API error:', response.data.error);
    }
  } catch (error) {
    console.error('Error sending message to Slack:', error.message);
  }
}

// Main function to run the task summary
async function generateAndSendSummary() {
  try {
    console.log('Starting task summary generation...');
    
    const currentUser = await getCurrentUser();
    const userId = currentUser.gid;
    console.log(`Logged in as: ${currentUser.name}`);
    
    const workspaces = await getWorkspaces();
    console.log(`Found ${workspaces.length} workspace(s)`);
    
    let allTasks = [];
    
    for (const workspace of workspaces) {
      console.log(`Processing workspace: ${workspace.name}`);
      
      // Get tasks assigned to user
      const userTasks = await getUserTasks(workspace.gid, userId);
      allTasks.push(...userTasks);
      
      // Get projects owned by user
      const ownedProjects = await getOwnedProjects(workspace.gid, userId);
      const projectIds = ownedProjects.map(p => p.gid);
      
      if (projectIds.length > 0) {
        // Get tasks in owned projects
        const projectTasks = await getTasksInOwnedProjects(projectIds);
        allTasks.push(...projectTasks);
      }
    }
    
    // Remove duplicates
    const uniqueTasks = Array.from(new Map(allTasks.map(t => [t.gid, t])).values());
    
    // Filter for due today or overdue
    const filteredTasks = filterDueTodayOrOverdue(uniqueTasks);
    console.log(`Found ${filteredTasks.length} due today or overdue tasks`);
    
    // Group by project
    const groupedTasks = await groupTasksByProject(filteredTasks);
    
    // Format and send
    const message = await formatSlackMessage(groupedTasks);
    await sendSlackMessage(message);
    
    console.log('Task summary completed successfully');
  } catch (error) {
    console.error('Error in generateAndSendSummary:', error);
  }
}

// Schedule the task for 6am AEST (8pm UTC previous day)
// AEST is UTC+10, so 6am AEST = 8pm UTC previous day
// Cron format: minute hour day month dayOfWeek
cron.schedule('0 20 * * *', () => {
  console.log('Running scheduled task summary at 8pm UTC (6am AEST next day)');
  generateAndSendSummary();
}, {
  timezone: 'UTC'
});

console.log('Scheduler started. Task will run daily at 8pm UTC (6am AEST next day)');

// Run once on startup for testing
console.log('Running initial task summary...');
generateAndSendSummary();
