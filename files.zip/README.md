# Asana Daily Task Summary to Slack

Automated daily summary of overdue and due-today Asana tasks, sent to Slack at 6am AEST.

## Features

✅ Monitors all Asana workspaces  
✅ Includes tasks assigned to you  
✅ Includes tasks in projects you own  
✅ Filters for due today or overdue only  
✅ Groups by project name  
✅ Sends as checklist to Slack DM  
✅ Runs automatically at 6am AEST daily  

## Deployment on Replit

### Step 1: Create a Replit Project

1. Go to [https://replit.com](https://replit.com)
2. Sign in with your account (or create one)
3. Click **"Create"** (top left)
4. Choose **"Node.js"** as the template
5. Name it something like `asana-slack-summary`

### Step 2: Add the Files

1. In Replit, delete the default `index.js` file
2. Click the **"+"** button to create a new file
3. Name it `asana-slack-summary.js`
4. Copy and paste the contents from the app file
5. Click **"+"** again to create `package.json`
6. Copy and paste the dependencies file

### Step 3: Install Dependencies

1. Click the **"Shell"** tab at the bottom
2. Run: `npm install`
3. Wait for it to complete

### Step 4: Start the App

1. Click the **"Run"** button (top center)
2. You should see output like:
   - `Scheduler started. Task will run daily at 8pm UTC (6am AEST next day)`
   - `Running initial task summary...`
   - `Message sent to Slack successfully`

If you see "Message sent to Slack successfully", everything is working! ✅

### Step 5: Keep It Running 24/7

By default, Replit stops the app when you close the browser. To keep it running:

1. Upgrade to **Replit Pro** (optional, ~$10/month)
   - OR use the free alternative below:

**Free Alternative: Use UptimeRobot**

1. Go to [https://uptimerobot.com](https://uptimerobot.com)
2. Sign up for free
3. Create a new **HTTP Monitor**:
   - URL: your Replit URL (copy from the browser tab)
   - Check interval: 5 minutes
4. This "pings" your app every 5 minutes to keep it alive
5. Your Replit URL will be shown at the top of the output

## How It Works

- **Runs at:** 8pm UTC daily (which is 6am AEST next day)
- **Fetches:** All tasks assigned to you + all tasks in projects you own
- **Filters:** Only shows tasks due today or overdue
- **Groups:** Organizes by project name
- **Sends:** Direct Slack message to your DM with a checklist format

## Testing

The app runs once on startup, so you'll see a summary immediately when you click "Run". Check your Slack DM to confirm it's working.

## Troubleshooting

**Message not appearing in Slack?**
- Check that your Slack User ID is correct (U07A8885UEB)
- Verify the Slack Bot Token starts with `xoxb-`
- Check Replit console for error messages

**No tasks showing?**
- Confirm you have tasks due today or overdue in Asana
- The app filters for `due_on <= today` and `completed = false`

**Scheduler not running?**
- Keep the Replit browser tab open or upgrade to Pro
- Or use UptimeRobot to keep it alive (see Step 5)

## Support

If the app stops working, check:
1. Asana token is still valid (regenerate if needed)
2. Slack bot token is still valid
3. Your Slack workspace hasn't revoked permissions
